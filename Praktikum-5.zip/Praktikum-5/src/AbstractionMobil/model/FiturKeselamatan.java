package model;

public interface FiturKeselamatan {
    void nyalakanAirbag();
    void aktifkanABS();
}
